function execute(url) {
    var browser = Engine.newBrowser() // Khởi tạo browser
    let doc = browser.launch(url, 2000) // Mở trang web với timeout, trả về Document object
    let chap = doc.select("#read-content").html()
    browser.close()
    return Response.success(chap);

}

