function execute(url) {
    // url = url.replace("hiepnu.net");
    let response = fetch(url);
    if (response.ok)
        return Response.success(response.html().select("#read-content").html());
    return null;
}
