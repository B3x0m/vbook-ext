function execute() {
    return Response.success([
        {title: "Đô Thị", input: "https://hiepnu.net/the-loai/do-thi", script: "gen.js"},
        {title: "Ngôn Tình", input: "https://hiepnu.net/the-loai/lang-man", script: "gen.js"},
        {title: "Huyền Huyễn", input: "https://hiepnu.net/the-loai/huyen-huyen", script: "gen.js"},
        {title: "Tiên Hiệp", input: "https://hiepnu.net/the-loai/tien-hiep", script: "gen.js"},
        {title: "Cổ Đại", input: "https://hiepnu.net/the-loai/co-dai", script: "gen.js"},
        {title: "Huyền Nghi Thần Quái", input: "https://hiepnu.net/the-loai/than-quai", script: "gen.js"},
        {title: "Khoa Huyễn", input: "https://hiepnu.net/the-loai/khoa-huyen", script: "gen.js"},
        {title: "Dã Sử", input: "https://hiepnu.net/the-loai/da-su", script: "gen.js"}
    ]);
}
