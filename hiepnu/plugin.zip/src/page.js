function execute(url) {
    // url = url.replace("hiepnu.net");
    let response = fetch(url);
    if (response.ok) {
        let page = doc.select(".pagination > li a[href~=paged]").last().text();
        let pageList = [];
        if (page) {
            let totalPage = parseInt(page);
            for (let i = 1; i <= totalPage; i++) {
                pageList.push(url + "?paged=" + i);
            }
        } else {
            pageList.push(url + "?paged=1");
        }
        return Response.success(pageList);
    }
    return null;
}
