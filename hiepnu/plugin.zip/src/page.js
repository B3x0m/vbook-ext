function execute(url) {
    // url = url.replace("hiepnu.net");
    let response = fetch(url);
    if (response.ok) {
        let doc = response.html();
        var next = doc.select(".pagination").select(".nav-prev").select("a").last().attr("href");

        if (next) next = next[1]
        console.log(next) 


        const data = [];
        for (var i = 0; i < next; i++) {
            data.push(url + "/paged=" + (i + 1));
        }

        return Response.success(data, next);
    }

    return null;
}
