function execute(url) {
    // url = url.replace("hiepnu.net");
    let response = fetch(url);
    if (response.ok) {
        var page = doc.select(".nexts a").attr("href").match(/page=(\d+)/);
        if (!page) {
            var size = parseInt(doc.select(".pagination > li").size());
            if (size > 0) {
                page = doc.select(".pagination > li > a").get(size - 2).attr("href").match(/paged=(\d+)/);
            }
        }
        if (page) page = parseInt(page[1]); else page = 1;
        var list = [];
        for (var i = 1; i <= page; i++) {
            list.push(url + "/?paged=" + i);
        }
        return Response.success(list);
    }

    return null;
}
