function execute() {
    return Response.success([
        {title: "New uploads", input: "https://nhentai.one", script: "gen.js"}
    ]);
}